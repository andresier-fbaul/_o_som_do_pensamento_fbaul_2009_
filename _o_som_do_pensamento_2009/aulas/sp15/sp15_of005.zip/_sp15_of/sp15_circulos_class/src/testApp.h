#ifndef _TEST_APP
#define _TEST_APP

#include "ofMain.h"
#include "circulo.h"


#define NUM_CIRCULOS 10

class testApp : public ofSimpleApp{

	public:

		void setup();
		void update();
		void draw();

		void keyPressed  (int key);
		void keyReleased (int key);

		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased();

		// agora NUM_CIRCULOS no ecran
		// uma array de objectos Circulo chamada circulo
		Circulo circulo[NUM_CIRCULOS];
	
		//comportamento do rato
		bool    followmouse;
//		int mouseX, mouseY;
	
		void go_mouse();
};

#endif

