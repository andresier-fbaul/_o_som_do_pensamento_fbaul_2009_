#include "ofMain.h"
#include "testApp.h"

// starfield3d - multimeios
// andr� sier, 20090316

int main( ){

	ofSetupOpenGL(1280,720, OF_FULLSCREEN);//OF_WINDOW);			// <-------- setup the GL context
		
	// this kicks off the running of my app
	// can be OF_WINDOW or OF_FULLSCREEN
	// pass in width and height too:
	
	ofRunApp(new testApp());
	
}
