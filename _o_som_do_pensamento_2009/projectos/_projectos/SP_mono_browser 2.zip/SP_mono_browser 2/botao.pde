
class Botao {
  int id;
  float x, y, w, h,w2,h2;
  int coroff,coron;
  int gain; 
  boolean on = false;
  boolean touch = false;
  PImage img;
  int bmax = 3;

  Botao(int i,  float _x, float _y, float _w , float _h  ) {
    id = i;
    x = _x;
    y = _y;
    w = _w;
    h = _h;
    w2 = w*0.5f;
    h2 = h*0.5f;    
    coroff = color(100);
    coron = color(200,250,200);
 //   println("--new botao "+i+" "+_x+" "+_y+" "+_w);
  } 


  void test(float _x, float _y, float dimx, float dimy) {
    float dx = x - _x;
    float dy = y - _y;
    if(abs(dx) <= (w2+dimx*0.5) && abs(dy) <= (h2+dimy*0.5)){
      gain++;  
      touch = true;
    }
  }

  void state(){    
    if(touch)
      touch=false;
    else
      gain--;
      
    if(gain>bmax){
      gain = bmax;
      on = true; 
    }
    if(gain<bmax)
      on = false;
    if(gain<0)
      gain=0;
      

      
  }

  void render(){
    state();
    int c0 = on ? coron : coroff;
  //  int c1 = on ? coroff : coron;
    fill(c0,map(gain,0,100,10,255));    
    rect(x,y,w,h);
    fill(255);
    text(""+gain,x,y);
    text(""+id,x,y+h2-2);
  }

}


