#include "ofMain.h"
#include "Objecto.h"

/*
    Objecto(float _x, float _y, float _z, float _r, float _c);
    ~Objecto();
    void update();
    void draw();
*/

// construtor
Objecto::Objecto(){




}


// destrutor
Objecto::~Objecto(){


}


void Objecto::init(float _x, float _y, float _z, float _r, float _c,float _v){

    x = _x;
    y = _y;
    z = _z;
    rad = _r;
    cor = _c;
    verde = _v;


}




void Objecto::update(float speed){

    z+=speed;//200.0f;//1.0f;//100.0;
    if(z>0)
        z = ZMAX;//-8000;

    cor = CLAMP( ofMap (z , ZMAX , 0 , 0, 255)  , 0 , 255) ;
    verde = CLAMP( ofMap (z , ZMAX , 0 , 0, 300)  , 0 , 300) ;

}



void Objecto::draw(){

//    pushMatrix();
//    translate(x,y,z);
//    //cor
//    fill(cor,cor,cor,255);
//    noStroke();
//    ellipse(0,0,rad,rad);
//    popMatrix();

    float c = cor/255.0f;

    float v = verde/255.0f;



    glPushMatrix();
    glTranslatef(x,y,z);
    glColor3f(c,v,c);
    ofCircle(0,0,rad);
    glPopMatrix();


}
