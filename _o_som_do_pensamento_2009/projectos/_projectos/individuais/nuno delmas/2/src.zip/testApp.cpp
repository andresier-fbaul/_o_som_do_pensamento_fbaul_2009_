#include "testApp.h"
#include "stdio.h"

//--------------------------------------------------------------
testApp::testApp(){

}

//--------------------------------------------------------------
void testApp::setup(){

    joyx = 0;//joystic
	joyy = 0;
	joyz = 0;


recording = false;


     grelhax = 20;
     grelhay = 20;
     grelhaz = 40;
     objcount = grelhax*grelhay*grelhaz;

     obj = new Objecto[objcount];

int w = 0;
  for(int i = 0; i < grelhax; i++) {
    for(int j = 0; j < grelhay; j++) {
      for(int k = 0; k < grelhaz; k++) {


        float x = ofMap (i , 0, grelhax-1, -5000,5000 );
        float y = ofMap (j , 0, grelhay-1, -5000,5000);
        float z = ofMap (k , 0, grelhaz-1, 0,ZMAX);//-8000);
        float rad = 50;
 //       float inverso;
        float cor = CLAMP( ofMap (z , ZMAX , 0 , 0, 255)  , 0 , 255)    ;// (z/255)+255;

        float verde = CLAMP( ofMap (z , ZMAX , 0 , 0, 300)  , 0, 300);

        obj[w].init(x,y,z,rad,cor,verde);// = new Objecto(x,y,z,rad,cor);
        //println("obj "+x+" "+y+" "+z+" "+rad+" "+cor);
        w++;


      }
    }
  }

 // println(w);



}

//--------------------------------------------------------------
void testApp::update(){

    float s = 100;//ofMap(mouseX,0,ofGetWidth(),0.,1000.0f);

  for(int i = 0; i < objcount ; i++) {

      obj[i].update(s);
    }
}

//----------------------------------------------billboarding

//void testApp::billboardSphericalBegin(float camX, float camY, float camZ,float objPosX, float objPosY, float objPosZ) {
//
//	float lookAt[3],objToCamProj[3],upAux[3];
//	float modelview[16],angleCosine;
//
//	glPushMatrix();
//
//// objToCamProj is the vector in world coordinates from the
//// local origin to the camera projected in the XZ plane
//	objToCamProj[0] = camX - objPosX ;
//	objToCamProj[1] = 0;
//	objToCamProj[2] = camZ - objPosZ ;
//
//// This is the original lookAt vector for the object
//// in world coordinates
//	lookAt[0] = 0;
//	lookAt[1] = 0;
//	lookAt[2] = 1;
//
//
//// normalize both vectors to get the cosine directly afterwards
//	mathsNormalize(objToCamProj);
//
//// easy fix to determine wether the angle is negative or positive
//// for positive angles upAux will be a vector pointing in the
//// positive y direction, otherwise upAux will point downwards
//// effectively reversing the rotation.
//
//	mathsCrossProduct(upAux,lookAt,objToCamProj);
//
//// compute the angle
//	angleCosine = mathsInnerProduct(lookAt,objToCamProj);
//
//// perform the rotation. The if statement is used for stability reasons
//// if the lookAt and objToCamProj vectors are too close together then
//// |angleCosine| could be bigger than 1 due to lack of precision
//   if ((angleCosine < 0.99990) && (angleCosine > -0.9999))
//      glRotatef(acos(angleCosine)*180/3.14,upAux[0], upAux[1], upAux[2]);
//
//// so far it is just like the cylindrical billboard. The code for the
//// second rotation comes now
//// The second part tilts the object so that it faces the camera
//
//// objToCam is the vector in world coordinates from
//// the local origin to the camera
//	objToCam[0] = camX - objPosX;
//	objToCam[1] = camY - objPosY;
//	objToCam[2] = camZ - objPosZ;
//
//// Normalize to get the cosine afterwards
//	mathsNormalize(objToCam);
//
//// Compute the angle between objToCamProj and objToCam,
////i.e. compute the required angle for the lookup vector
//
//	angleCosine = mathsInnerProduct(objToCamProj,objToCam);
//
//
//// Tilt the object. The test is done to prevent instability
//// when objToCam and objToCamProj have a very small
//// angle between them
//
//	if ((angleCosine < 0.99990) && (angleCosine > -0.9999))
//		if (objToCam[1] < 0)
//			glRotatef(acos(angleCosine)*180/3.14,1,0,0);
//		else
//			glRotatef(acos(angleCosine)*180/3.14,-1,0,0);
//
//}
//


//----------------------------------------------------------------------------------
//--------------------------------------------------------------
void testApp::draw(){


//mesmonofim   para gravar imagems




    ofBackground(0,0,0);

    //camera
    float fov = 60.f;//120.f;//90.f;
	float w = ofGetWidth();
	float h = ofGetHeight();
	float ratio = w/h;
	float z = 1.0f;
	float Z = 1000000.0f;//50000.0f;//20000.0f;

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(fov, ratio, z, Z);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
//	gluLookAt(0.f, 0.f, 100.f,		0.f, 0.f ,0.f,		0.,1.,0.);

     float x = ofMap(mouseX,0,ofGetWidth(), -10000,10000);
    float y = ofMap(mouseY,0,ofGetHeight(), -10000,10000);

    gluLookAt( ofMap(joyx,-255,255,-2000,2000) , ofMap(joyy,-255,255,-2000,2000) , 1000 , ofMap(joyx,-255,255,-2000,2000)+ofMap(joyz,-255,255,-250,250) , ofMap(joyy,-255,255,-2000,2000) , 0 , 0 , 0.5 , 0 );
//codigo dos butoes
//if (joybuttons[0]==true){
//
//
//    }













   // glDisable(GL_DEPTH_TEST);
    glEnable(GL_DEPTH_TEST);
//    glEnable(GL_BLEND);
//      glBlendFunc(GL_SRC_ALPHA,GL_ONE);

      for(int i = 0; i < objcount ; i++) {

      obj[i].draw();
    }

////billboarding
//// restores the modelview matrix
//glPopMatrix();


       if(recording){

               ofImage frame;
               frame.grabScreen(0,0,ofGetWidth(), ofGetHeight());
               string fileName = "rADIACAO-" + ofToString(ofGetDay()) +"-"+
               ofToString(ofGetDay())  +"-"+
               ofToString(ofGetHours())  +"-"+
               ofToString(ofGetMinutes())  +"-"+
               ofToString(ofGetFrameNum()) + ".bmp";

               frame.saveImage(fileName);
               recording=false;
       }

            //para gravar imagems
}
//--------------------------------------------------------------
void testApp::joystick(unsigned int buttonMask, int x, int y, int z) {

	// retrieve each button by masking the int with powers of two
	for(int i=0;i<joynumbuttons;i++){
		joybuttons[i] =  (buttonMask & (1<<i));
	}

	joyx = x;
	joyy = y;
	joyz = z;

}
//--------------------------------------------------------------
void testApp::keyPressed  (int key){

 if(key=='s'){
        recording^=true;
       }
}

//--------------------------------------------------------------
void testApp::keyReleased(int key){

}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::resized(int w, int h){

}

