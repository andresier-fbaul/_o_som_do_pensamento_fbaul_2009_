import processing.core.*; 
import processing.xml.*; 

import processing.opengl.*; 

import java.applet.*; 
import java.awt.*; 
import java.awt.image.*; 
import java.awt.event.*; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class SP_mono_browser extends PApplet {

/*
SONS DO PENSAMENTO
browser de projectos
andr\u00e9 sier
090630
 */


//import processing.video.*;
//import s373.flob.*;
//import ddf.minim.*;

Monoflob mono;


PFont font,fontbig, fontsmall;
PImage bgimage;

String  projectos[];
String path = "/O_SOM_DO_PENSAMENTO_2009/"; // criar uma pasta na raiz do disco com este nome para ter os exes

String stat="";

int lastLaunch;
int MIN_LAUNCH_PERIOD_MS = 3000;
int STAT_PERIOD_AFTER_LAUNCH = 6000;




//fullscreen window
public void init(){
  lastLaunch=0;
  frame.dispose();
  frame.setUndecorated(true);
  //frame.set
//  GraphicsDevice myGraphicsDevice = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
//  myGraphicsDevice.setFullScreenWindow(frame);
  super.init();
}


public void setup(){

  size(screen.width ,screen.height,OPENGL);
  frame.setLocation(0,0);
  frameRate(10);
  rectMode(CENTER);

  font = createFont("monaco",12);
  fontbig = createFont("monaco",25);
  fontsmall = createFont("monaco",9);
  textFont(font);

  bgimage = loadImage("sonspensamento2048512.jpg");

  projectos = loadStrings("proj_database.txt");
  println("--SP-mono-browser");
  println("--projectos:");
  println();
  println(projectos);
  
  
  mono = new Monoflob(2,2);//(3,2);//(2,2);


}



public void draw(){


    background(0,0,100);
    
    tint(255,100);
    image(bgimage, 250, 0, width-247, (float)height*0.25f);//512);
    fill(0,200);
    rect(125,height/2,250,height);




  
    if(mousePressed)
       mono.touch(mouseX,mouseY,20,20);
    else
       mono.touchover(mouseX,mouseY,20,20);
    
  
    mono.render();


    fill(255,170);
    textFont(font);
    text(stat, 5, height*0.2f);


}


public void keyPressed(){
 if(key==ESC){//intercept esc
   key=0;
   println("esc"+frameCount); 
 }
}






class Monoflob{
  //Botao b[];
  //BotaoAudio b[];
  BotaoTxt b[];
  int gx,gy,num;
  float dimx,dimy;
  float sizex,sizey;//1.0 max
  
  Monoflob(int _gx, int _gy){
    gx = _gx;
    gy = _gy;
    sizex = 0.8f;//0.75;
    sizey = 0.5f;
    float stridex = (float)width*0.7f / (float)gx;//(float)width*0.5 / (float)gx;
    float stridey = (float)height*0.8f / (float)gy;//(float)height*0.5 / (float)gy;
    dimx = stridex * sizex ;
    dimy = stridey * sizey ;
    
    num = gx * gy;
print("num: " + num + "dimxdimy: " + dimx + "," + dimy);    
//    b = new BotaoAudio[num];
    b = new BotaoTxt[num];

float extra;
if(height <= 768)
  extra = 0.85f;//0.65;
else
  extra = 1.7f;

    for(int i=0; i<num;i++){
       float x =  ((float)(i % gx) +1.05f) * stridex +50 ;
       float y = ((float)(i / gx) +extra) *stridey ;
       b[i] = new BotaoTxt(i, x,y,dimx,dimy);      
    }        
        
  }
  
  public void touch(float x, float y,float w, float h){    
    for(int i=0; i<num; i++)
      b[i].test(x,y,w,h);    
  }
 public void touchover(float x, float y,float w, float h){    
    for(int i=0; i<num; i++)
      b[i].testover(x,y,w,h);    
  }

  public void render(){

    
    for(int i=0; i<num; i++)
      b[i].render();   
  }


}

  
class Botao {
  int id;
  float x, y, w, h,w2,h2;
  int coroff,coron;
  int gain; 
  boolean on = false;
  boolean touch = false;
  PImage img;
  int bmax = 1;

  Botao(int i,  float _x, float _y, float _w , float _h  ) {
    id = i;
    x = _x;
    y = _y;
    w = _w;
    h = _h;
    w2 = w*0.5f;
    h2 = h*0.5f;    
    coroff = color(100);
    coron = color(200,250,200);
 //   println("--new botao "+i+" "+_x+" "+_y+" "+_w);
  } 


  public void test(float _x, float _y, float dimx, float dimy) {
    float dx = x - _x;
    float dy = y - _y;
    if(abs(dx) <= (w2+dimx*0.5f) && abs(dy) <= (h2+dimy*0.5f)){
      gain++;  
      touch = true;
    }
  }

  public void testover(float _x, float _y, float dimx, float dimy) {
    float dx = x - _x;
    float dy = y - _y;
    if(abs(dx) <= (w2+dimx*0.5f) && abs(dy) <= (h2+dimy*0.5f)){
      on=true;
    }
    else {
      on = false;
    }
  }


  public void state(){    
    if(touch)
      touch=false;
    else
      gain--;
      
    if(gain>bmax){
      gain = bmax;
      on = true; 
    }
//    if(gain<bmax)
//      on = false;
    if(gain<0)
      gain=0;
      

      
  }

  public void render(){
    state();
    int c0 = on ? coron : coroff;
  //  int c1 = on ? coroff : coron;
    fill(c0,map(gain,0,100,10,255));    
    rect(x,y,w,h);
    fill(255);
    text(""+gain,x,y);
    text(""+id,x,y+h2-2);
  }

}




class BotaoTxt extends Botao{

  String autor;
  String titulo;
  PImage img;
  String descricao;
  String executaveis[];
  String displayinfo;

  BotaoTxt(int i,  float _x, float _y, float _w , float _h ){
    super(i,_x,_y,_w,_h); //construtor botao normal

    // ler a info do texto a partir do texto global
    autor = trim( projectos[i*6 + 1] );
    titulo = trim( projectos[i*6 + 2] );
    img = loadImage( trim(projectos[i*6 + 3]) );
    descricao = trim( projectos[i*6 + 4] );
    executaveis = split ( trim( projectos[i*6 + 5]) , ' '); 
    
    displayinfo = titulo+"\n"+autor;//+"\n"+descricao;
    println("----projecto do "+autor+" "+titulo+" "+descricao+" "+executaveis);
println("render: " + x + "," + y);    
  }

  // overloading state to handle sound here
  public void state(){
    //print("inState");

    super.state();
    
    int nowMs = millis();
        
    if(on && (gain >= bmax) && (nowMs - lastLaunch > MIN_LAUNCH_PERIOD_MS)){
//      gain=0;
      lastLaunch=nowMs;
      on=false;
      print("1: " + nowMs +"-"+lastLaunch+"-"+stat);
      execute();
    }
    else
    if((stat != "") && (nowMs - lastLaunch > STAT_PERIOD_AFTER_LAUNCH)){
//      print("2: " + nowMs +"-"+lastLaunch+"-"+stat);
      stat = "";
    }    

      
  }
  
  public void execute(){
//   println("execute called!! botao "+id); 

      stat = "loading "+ trim(titulo)+"...";
      stat += "\n\ncarregue em 'esc' para sair do\ntrabalho actual e escolher outro";

      String file = path + executaveis[0];
      open(file);
      
      for(int i=1;i<executaveis.length;i++){
       
       if(executaveis[i]!="") {
        
        file = path + executaveis[i];
        open(file);
       } 
        
      }

    //  stat = 
  }
  
  
  public void render(){
      
    state();
    int c0 = on ? coron : coroff;
    fill(c0,map(gain,0,100,10,255));    
    rect(x,y,w,h);
    tint(c0, on?255:100);
    if(img != null)
      image(img, x-w2,y-h2,w,h);
    fill(255);


    textFont(font);
    text(displayinfo,x-w2,y+h2+10);

// split descricao by \n    
    String[] descList = split(descricao, "\\n");

    textFont(fontsmall);
    float yy=y+h2+45;
    for(int i=0; i<descList.length; i++){
      text(trim(descList[i]),x-w2,yy);
      yy+=(textAscent() + textDescent()) * 1.5f;
    }


  }

}



  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#ffffff", "SP_mono_browser" });
  }
}
