

class BotaoTxt extends Botao{

  String autor;
  String titulo;
  PImage img;
  String descricao;
  String executaveis[];
  String displayinfo;

  BotaoTxt(int i,  float _x, float _y, float _w , float _h ){
    super(i,_x,_y,_w,_h); //construtor botao normal

    // ler a info do texto a partir do texto global
    autor = trim( projectos[i*6 + 1] );
    titulo = trim( projectos[i*6 + 2] );
    img = loadImage( trim(projectos[i*6 + 3]) );
    descricao = trim( projectos[i*6 + 4] );
    executaveis = split ( trim( projectos[i*6 + 5]) , ' '); 
    
    displayinfo = titulo+"\n"+autor;//+"\n"+descricao;
    println("----projecto do "+autor+" "+titulo+" "+descricao+" "+executaveis);
println("render: " + x + "," + y);    
  }

  // overloading state to handle sound here
  void state(){
    //print("inState");

    super.state();
    
    int nowMs = millis();
        
    if(on && (gain >= bmax) && (nowMs - lastLaunch > MIN_LAUNCH_PERIOD_MS)){
//      gain=0;
      lastLaunch=nowMs;
      on=false;
      print("1: " + nowMs +"-"+lastLaunch+"-"+stat);
      execute();
    }
    else
    if((stat != "") && (nowMs - lastLaunch > STAT_PERIOD_AFTER_LAUNCH)){
//      print("2: " + nowMs +"-"+lastLaunch+"-"+stat);
      stat = "";
    }    

      
  }
  
  void execute(){
//   println("execute called!! botao "+id); 

      stat = "loading "+ trim(titulo)+"...";
      stat += "\n\ncarregue em 'esc' para sair do\ntrabalho actual e escolher outro";

      String file = path + executaveis[0];
      open(file);
      
      for(int i=1;i<executaveis.length;i++){
       
       if(executaveis[i]!="") {
        
        file = path + executaveis[i];
        open(file);
       } 
        
      }

    //  stat = 
  }
  
  
  void render(){
      
    state();
    int c0 = on ? coron : coroff;
    fill(c0,map(gain,0,100,10,255));    
    rect(x,y,w,h);
    tint(c0, on?255:100);
    if(img != null)
      image(img, x-w2,y-h2,w,h);
    fill(255);


    textFont(font);
    text(displayinfo,x-w2,y+h2+10);

// split descricao by \n    
    String[] descList = split(descricao, "\\n");

    textFont(fontsmall);
    float yy=y+h2+45;
    for(int i=0; i<descList.length; i++){
      text(trim(descList[i]),x-w2,yy);
      yy+=(textAscent() + textDescent()) * 1.5;
    }


  }

}


